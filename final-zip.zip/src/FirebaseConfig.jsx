import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyA96VQaK-pJlD3tpBNamLNZuKwLJi5Vl5Q",
  authDomain: "test-fff9c.firebaseapp.com",
  projectId: "test-fff9c",
  storageBucket: "test-fff9c.appspot.com",
  messagingSenderId: "97762417673",
  appId: "1:97762417673:web:7a5bb218aee2da40b42cd8",
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
export default auth;
