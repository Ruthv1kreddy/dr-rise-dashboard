import { Person } from "@mui/icons-material";
import { Avatar, Box, Divider, Grid, Stack, Typography } from "@mui/material";
import { green, grey } from "@mui/material/colors";
import React from "react";
import InforBoxItem from "./InforBoxItem";

const InfoBoxes = () => {
  return (
    <Grid container spacing={2} rowSpacing={3} alignItems="stretch">
      <Grid item xs={12} md={4}>
        <InforBoxItem></InforBoxItem>
      </Grid>
      <Grid item xs={12} md={4}>
        <InforBoxItem></InforBoxItem>
      </Grid>
      <Grid item xs={12} md={4}>
        <InforBoxItem></InforBoxItem>
      </Grid>
    </Grid>
  );
};

export default InfoBoxes;
