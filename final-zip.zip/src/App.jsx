import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import Signup, { loginaction } from "./components/Signup";
import firebase from "./FirebaseConfig";
import FirebaseAuthService from "./FirebaseAuthService";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import RootLayout from "./pages/Root";
import Home from "./pages/Home";
import HomeLayout from "./pages/HomeLayout";
import { onAuthStateChanged } from "firebase/auth";
import auth from "./FirebaseConfig";

const router = createBrowserRouter([
  {
    path: "/",
    element: <RootLayout />,
    children: [
      {
        path: "/",
        element: <Signup></Signup>,
        action: loginaction,
      },
    ],
  },
  {
    path: "/home",
    element: <HomeLayout></HomeLayout>,
    children: [
      {
        path: "/home",
        element: <Home></Home>,
      },
    ],
  },
]);
function App() {
  const [user, setUser] = useState(null);
  onAuthStateChanged(auth, (userparam) => {
    setUser(userparam);
  });

  return <RouterProvider router={router}></RouterProvider>;
}

export default App;
